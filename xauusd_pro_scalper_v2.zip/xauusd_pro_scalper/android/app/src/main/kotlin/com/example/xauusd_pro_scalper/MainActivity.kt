package com.example.xauusd_pro_scalper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
