import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/services/notification_service.dart';

class SignalProvider extends ChangeNotifier {
  String side = 'NONE'; // BUY / SELL / NONE
  double price = 2650.00;
  double change = 0.0;
  double spread = 0.18;
  double confidence = 0;
  String entry = '-';
  String sl = '-';
  String tp1 = '-';
  String tp2 = '-';
  bool isRunning = false;
  String status = 'Siap';
  int signalCount = 0;

  Timer? _timer;
  final _rnd = Random();

  // Simulasi harga + sinyal (gratis, tidak butuh API berbayar)
  // Nanti bisa diganti WebSocket gratis (Finnhub free key)
  void start() {
    if (isRunning) return;
    isRunning = true;
    status = 'Background aktif • Menunggu sinyal';
    notifyListeners();

    _timer = Timer.periodic(const Duration(seconds: 8), (_) {
      _updatePrice();
      _checkSignal();
    });
  }

  void stop() {
    _timer?.cancel();
    isRunning = false;
    status = 'Dihentikan';
    notifyListeners();
  }

  void _updatePrice() {
    // Simulasi pergerakan kecil XAUUSD
    final move = (_rnd.nextDouble() - 0.48) * 1.8;
    price = double.parse((price + move).toStringAsFixed(2));
    change = move;
    spread = 0.12 + _rnd.nextDouble() * 0.15;
    notifyListeners();
  }

  void _checkSignal() async {
    // Filter ketat untuk akurasi tinggi (hanya keluar kalau kondisi bagus)
    final hour = DateTime.now().hour;
    final isGoodSession = (hour >= 7 && hour < 11) || (hour >= 19 && hour < 23); // London / NY WIB kira-kira
    final spreadOk = spread <= 0.25;

    if (!isGoodSession || !spreadOk) {
      side = 'NONE';
      confidence = 0;
      status = 'Filter: di luar session / spread tinggi';
      notifyListeners();
      return;
    }

    // Simulasi confluence score
    final score = 60 + _rnd.nextInt(40); // 60-99

    if (score >= 82) {
      final isBuy = _rnd.nextBool();
      side = isBuy ? 'BUY' : 'SELL';
      confidence = score.toDouble();

      if (isBuy) {
        entry = (price - 0.8).toStringAsFixed(2);
        sl = (price - 4.5).toStringAsFixed(2);
        tp1 = (price + 3.2).toStringAsFixed(2);
        tp2 = (price + 6.5).toStringAsFixed(2);
      } else {
        entry = (price + 0.8).toStringAsFixed(2);
        sl = (price + 4.5).toStringAsFixed(2);
        tp1 = (price - 3.2).toStringAsFixed(2);
        tp2 = (price - 6.5).toStringAsFixed(2);
      }

      signalCount++;
      status = 'SINYAL $side • Confidence $score%';

      // Alarm berbunyi (hanya sekali per sinyal)
      final prefs = await SharedPreferences.getInstance();
      final last = prefs.getInt('last_signal') ?? 0;
      final now = DateTime.now().millisecondsSinceEpoch;
      if (now - last > 120000) { // minimal 2 menit antar sinyal
        await prefs.setInt('last_signal', now);
        await NotificationService.showEntryAlarm(
          side: side,
          entry: entry,
          sl: sl,
          tp1: tp1,
          confidence: score,
        );
      }
    } else {
      side = 'NONE';
      confidence = score.toDouble();
      status = 'Menunggu confluence ≥ 82%';
    }
    notifyListeners();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
