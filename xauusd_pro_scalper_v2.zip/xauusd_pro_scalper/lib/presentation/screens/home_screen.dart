import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../domain/engines/signal_provider.dart';
import '../widgets/signal_led.dart';
import '../widgets/price_header.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Consumer<SignalProvider>(
          builder: (context, sp, _) {
            return Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  child: Row(
                    children: [
                      const Icon(Icons.show_chart, color: Color(0xFFFFD700), size: 28),
                      const SizedBox(width: 8),
                      const Text(
                        'XAUUSD PRO SCALPER',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: sp.isRunning ? const Color(0xFF00C853).withOpacity(0.2) : Colors.grey.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 8, height: 8,
                              decoration: BoxDecoration(
                                color: sp.isRunning ? const Color(0xFF00C853) : Colors.grey,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              sp.isRunning ? 'LIVE' : 'OFF',
                              style: TextStyle(
                                color: sp.isRunning ? const Color(0xFF00C853) : Colors.grey,
                                fontSize: 12, fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // Harga
                PriceHeader(
                  price: sp.price,
                  change: sp.change,
                  spread: sp.spread,
                ),

                const SizedBox(height: 12),

                // LED Sinyal besar
                SignalLed(
                  side: sp.side,
                  confidence: sp.confidence,
                  entry: sp.entry,
                  sl: sp.sl,
                  tp1: sp.tp1,
                  tp2: sp.tp2,
                ),

                const SizedBox(height: 16),

                // Status bar
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A1A),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white10),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        sp.side == 'NONE' ? Icons.hourglass_empty : Icons.notifications_active,
                        color: sp.side == 'BUY'
                            ? const Color(0xFF00C853)
                            : sp.side == 'SELL'
                                ? const Color(0xFFFF1744)
                                : Colors.grey,
                        size: 20,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          sp.status,
                          style: const TextStyle(fontSize: 13, color: Colors.white70),
                        ),
                      ),
                    ],
                  ),
                ),

                const Spacer(),

                // Tombol Start / Stop
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  child: Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: sp.isRunning ? null : () => sp.start(),
                          icon: const Icon(Icons.play_arrow),
                          label: const Text('START', style: TextStyle(fontWeight: FontWeight.bold)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF00C853),
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: sp.isRunning ? () => sp.stop() : null,
                          icon: const Icon(Icons.stop),
                          label: const Text('STOP', style: TextStyle(fontWeight: FontWeight.bold)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFF1744),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
