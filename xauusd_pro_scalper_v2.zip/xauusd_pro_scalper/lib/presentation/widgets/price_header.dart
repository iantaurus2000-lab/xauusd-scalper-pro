import 'package:flutter/material.dart';

class PriceHeader extends StatelessWidget {
  final double price;
  final double change;
  final double spread;

  const PriceHeader({
    super.key,
    required this.price,
    required this.change,
    required this.spread,
  });

  @override
  Widget build(BuildContext context) {
    final isUp = change >= 0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Text(
            price.toStringAsFixed(2),
            style: const TextStyle(
              fontSize: 42,
              fontWeight: FontWeight.w800,
              letterSpacing: -1,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '${isUp ? '+' : ''}${change.toStringAsFixed(2)}',
                style: TextStyle(
                  color: isUp ? const Color(0xFF00C853) : const Color(0xFFFF1744),
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(width: 16),
              Text(
                'Spread ${spread.toStringAsFixed(2)}',
                style: const TextStyle(color: Colors.white54, fontSize: 14),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
