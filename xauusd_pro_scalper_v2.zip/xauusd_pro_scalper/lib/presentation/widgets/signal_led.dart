import 'package:flutter/material.dart';

class SignalLed extends StatelessWidget {
  final String side;
  final double confidence;
  final String entry;
  final String sl;
  final String tp1;
  final String tp2;

  const SignalLed({
    super.key,
    required this.side,
    required this.confidence,
    required this.entry,
    required this.sl,
    required this.tp1,
    required this.tp2,
  });

  @override
  Widget build(BuildContext context) {
    final isBuy = side == 'BUY';
    final isSell = side == 'SELL';
    final isActive = isBuy || isSell;

    final color = isBuy
        ? const Color(0xFF00C853)
        : isSell
            ? const Color(0xFFFF1744)
            : Colors.grey.shade700;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4), width: 1.5),
        boxShadow: isActive
            ? [BoxShadow(color: color.withOpacity(0.25), blurRadius: 20, spread: 4)]
            : null,
      ),
      child: Column(
        children: [
          // LED Circle
          Container(
            width: 110,
            height: 110,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.15),
              border: Border.all(color: color, width: 4),
              boxShadow: isActive
                  ? [BoxShadow(color: color.withOpacity(0.6), blurRadius: 18, spread: 0)]
                  : null,
            ),
            child: Center(
              child: Text(
                isActive ? side : 'WAIT',
                style: TextStyle(
                  color: color,
                  fontSize: isActive ? 22 : 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            isActive ? 'ENTRY READY' : 'MENUNGGU SINYAL',
            style: TextStyle(
              color: color,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          if (isActive) ...[
            const SizedBox(height: 6),
            Text(
              'Confidence ${confidence.toStringAsFixed(0)}%',
              style: TextStyle(color: color.withOpacity(0.9), fontSize: 14),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _info('ENTRY', entry, Colors.white),
                _info('SL', sl, const Color(0xFFFF1744)),
                _info('TP1', tp1, const Color(0xFF00C853)),
                _info('TP2', tp2, const Color(0xFF00C853)),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _info(String label, String value, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 11, color: Colors.white54)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: color)),
      ],
    );
  }
}
