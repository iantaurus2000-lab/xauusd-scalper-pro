import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:audioplayers/audioplayers.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static final _player = AudioPlayer();

  static Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings);

    // Channel khusus alarm entry (penting!)
    const channel = AndroidNotificationChannel(
      'entry_alarm',
      'Entry Alarm',
      description: 'Sinyal entry scalping XAUUSD',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
    );

    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  static Future<void> showEntryAlarm({
    required String side,
    required String entry,
    required String sl,
    required String tp1,
    required int confidence,
  }) async {
    // Coba mainkan suara (taruh file alarm_entry.mp3 di assets/sounds/)
    try {
      await _player.play(AssetSource('sounds/alarm_entry.mp3'));
    } catch (_) {}

    final isBuy = side.toUpperCase() == 'BUY';
    final title = isBuy ? '🟢 BUY ENTRY READY' : '🔴 SELL ENTRY READY';
    final body = 'Entry $entry | SL $sl | TP1 $tp1 | $confidence%';

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'entry_alarm',
        'Entry Alarm',
        channelDescription: 'Sinyal entry scalping',
        importance: Importance.max,
        priority: Priority.max,
        playSound: true,
        enableVibration: true,
        fullScreenIntent: true,
        category: AndroidNotificationCategory.alarm,
        visibility: NotificationVisibility.public,
        ticker: 'XAUUSD Signal',
      ),
    );

    await _plugin.show(
      1001,
      title,
      body,
      details,
      payload: 'open_chart',
    );
  }

  static Future<void> showBackgroundStatus(String text) async {
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'bg_status',
        'Background Status',
        channelDescription: 'Status menunggu sinyal',
        importance: Importance.low,
        priority: Priority.low,
        ongoing: true,
        showWhen: false,
      ),
    );
    await _plugin.show(888, 'XAUUSD Pro Scalper', text, details);
  }
}
