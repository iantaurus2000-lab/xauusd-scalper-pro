import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'core/services/background_service.dart';
import 'core/services/notification_service.dart';
import 'core/theme/app_theme.dart';
import 'presentation/screens/home_screen.dart';
import 'domain/engines/signal_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  // Minta permission penting
  await [
    Permission.notification,
    Permission.ignoreBatteryOptimizations,
  ].request();

  await NotificationService.init();
  await initializeBackgroundService();

  runApp(
    ChangeNotifierProvider(
      create: (_) => SignalProvider()..start(),
      child: const XauProApp(),
    ),
  );
}

class XauProApp extends StatelessWidget {
  const XauProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'XAUUSD Pro Scalper',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const HomeScreen(),
    );
  }
}
