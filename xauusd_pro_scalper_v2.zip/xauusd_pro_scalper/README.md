# XAUUSD Pro Scalper

Aplikasi scalping XAUUSD (Gratis).

## Cara Build dari HP

1. Buat repository baru di GitHub
2. Upload SEMUA isi folder ini (atau upload file ZIP ini lalu extract manual)
3. Pastikan file `.github/workflows/build.yml` ada
4. Buka tab **Actions**
5. Pilih **Build APK (Gratis)** → **Run workflow**
6. Tunggu 4-7 menit
7. Download artifact APK

## Fitur
- Background service
- Notifikasi + Alarm entry
- LED sinyal BUY / SELL
- Filter akurasi (session + spread)
